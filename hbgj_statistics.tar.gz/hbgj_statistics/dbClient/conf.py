import redis


source_db = {
    'host': '58.83.130.94',
     'user': 'query',
    'password': 'qureybyno',
    'database': 'skyhotel',
    'port': 3306
}

car_db = {
    'host': '58.83.139.234',
    'database': 'fmall',
    'user': 'query',
    'password': 'qureybyno',
    'port': 3307
}

# target_db = {
#     'host': '192.168.76.23',
#     'database': 'statistics',
#     'user': 'lpj',
#     'password': '123456',
#     'port': 3306
# }

target_db = {
    'host': '58.83.130.96',
    'database': 'promotion',
    'user': 'bi',
    'password': 'bIbi_0820',
    'port': 3306
}

target_db_test = {
    'host': '58.83.130.96',
    'database': 'bi',
    'user': 'bi',
    'password': 'bIbi_0820',
    'port': 3306
}

ApiLog_db = {
    'host': '43.241.230.186',
    'database': 'apiflumelog',
    'user': 'apilog',
    'password': 'apilog',
    'port': 3306
}

# ApiLog_db = {
#     'host': '43.241.208.217',
#     'database': 'apiflumelog',
#     'user': 'apilog',
#     'password': 'apilog',
#     'port': 3306
# }


oracle_db = {
    'ip': '58.83.130.94',
    'port': 1521,
    'sid': 'ora9i',
    'user': 'et',
    'password': 'atet501'
}

huoli_db = {
    'host': '58.83.130.108',
    'database': 'travel',
    'user': 'travel',
    'password': 'tral0923',
    'port': 3306
}

gt_db = {
    'host': '58.83.130.81',
    'database': 'gtgj',
    'user': 'query',
    'password': 'query1204',
    'port': 3306
}

redis_db = {
    'host': '127.0.0.1',
    'port': 6379,
    'db': 1
}

# sky_hotel = {
#     'host': '43.241.220.160',
#     'database': 'skyhotel',
#     'user': 'tongji',
#     'password': 'zctongji',
#     'port': 3306
# }
sky_hotel = {
    'host': '43.241.220.160',
    'database': 'skyhotel',
    'user': 'skyhuser',
    'password': 'skyht@34',
    'port': 33306
}

mail = {
    'mail_server': 'smtp.sina.com',
    'port': 25,
    'username': 'zhangchao_notice@sina.com',
    'password': 'a15072320712'

}

hb_fly = {
    'ip': '58.83.130.94',
    'port': 1521,
    'sid': 'ora9i',
    'user': 'flightdyn',
    'password': 'flight0515'
}

localytics = {
    ""
}

pool = redis.ConnectionPool(host=redis_db['host'], port=redis_db['port'], db=redis_db['db'])
redis_cli = redis.Redis(connection_pool=pool)