from hbdt_details_history import insert_hbdt_details_weekly_history
from hbdt_details_history import insert_hbdt_details_monthly_history
from hbdt_details_history import insert_hbdt_details_quarterly_history

if __name__ == "__main__":
    insert_hbdt_details_weekly_history()
    insert_hbdt_details_monthly_history()
    insert_hbdt_details_quarterly_history()