from hbdt_search_history import insert_hbdt_search_weekly_history
from hbdt_search_history import insert_hbdt_search_monthly_history
from hbdt_search_history import insert_hbdt_search_quarterly_history

if __name__ == "__main__":
    insert_hbdt_search_weekly_history()
    insert_hbdt_search_monthly_history()
    insert_hbdt_search_quarterly_history()