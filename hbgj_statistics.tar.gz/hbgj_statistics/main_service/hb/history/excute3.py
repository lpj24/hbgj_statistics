from hbdt_details_history import insert_hbdt_details_quarterly_history
from hbdt_search_history import insert_hbdt_search_monthly_history

if __name__ == "__main__":
    #insert_hbdt_details_quarterly_history()
    insert_hbdt_search_monthly_history()